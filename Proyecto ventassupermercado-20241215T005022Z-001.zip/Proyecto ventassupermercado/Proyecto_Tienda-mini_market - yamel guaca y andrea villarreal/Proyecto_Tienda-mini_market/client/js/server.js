const express = require('express');
const app = express();
const mercadopago = require('mercadopago');

// Configurar MercadoPago con tu Access Token
mercadopago.configurations.setAccessToken('TEST-5039245334496260-121019-32235094ae64b8f992c7b34cd3bf5f87-246605165');

app.use(express.json());

// Ruta para crear preferencia de pago
app.post('/create_preference', (req, res) => {
    let preference = {
        items: req.body.items,
        back_urls: {
            success: "http://localhost:8080/success",
            failure: "http://localhost:8080/failure",
            pending: "http://localhost:8080/pending"
        },
        auto_return: "approved",
    };

    mercadopago.preferences.create(preference)
        .then(response => {
            res.json({
                id: response.body.id
            });
        })
        .catch(error => {
            console.log(error);
            res.status(500).send('Error al crear la preferencia');
        });
});

// Rutas para manejar los resultados de pago
app.get('/success', (req, res) => res.send('Pago realizado exitosamente!'));
app.get('/failure', (req, res) => res.send('El pago falló.'));
app.get('/pending', (req, res) => res.send('El pago está pendiente.'));

app.listen(8080, () => {
    console.log('Servidor escuchando en el puerto 8080');
});